# Roadmap
1. Projektgerüst
2. Suche
3. RAG
4. eAkte
5. Dokumentgenerator
