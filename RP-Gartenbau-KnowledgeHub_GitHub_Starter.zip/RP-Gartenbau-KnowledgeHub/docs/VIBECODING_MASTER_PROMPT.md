# Vibe Coding Master Prompt

Erstelle eine Desktop-Anwendung mit:
- Tauri
- React
- TypeScript
- SQLite + FTS5
- Markdown Knowledge Base
- Offlinebetrieb
- RAG-KI mit optionaler API (OpenAI/Claude/Gemini/OpenRouter/Ollama)
- Quellenangaben
- Dashboard
- Kontaktverwaltung
- Checklisten
- Flowcharts
- Dokumentgenerator
- GitHub-Versionierung
