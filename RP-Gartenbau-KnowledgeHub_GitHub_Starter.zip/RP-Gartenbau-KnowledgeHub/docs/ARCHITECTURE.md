# Architektur
Frontend: React + TypeScript
Desktop: Tauri
DB: SQLite + FTS5
Content: Markdown
KI: RAG
