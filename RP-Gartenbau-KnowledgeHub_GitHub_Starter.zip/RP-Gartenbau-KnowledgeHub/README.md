# RP-Gartenbau Knowledge Hub

Offline-Wissensportal für die Ausbildungsberatung Gartenbau.
